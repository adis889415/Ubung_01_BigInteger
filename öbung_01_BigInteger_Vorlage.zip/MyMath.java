package mypack.math;

import java.math.BigInteger;

/**
 * implementation of some mathematical utilities
 * @author msb
 * @version 1.0
 *
*/
public class MyMath 
{

	////////////// -fakultaet- //////////////	
	/**
	 * calculates faculty of n
	 * @param n
	 * @return faculty of n
	 */
	public static long fakultaet(long n) 
	{
		long produkt = 1;
		for (int i = 2; i <= n; i++)
			produkt *= i;

		return produkt;
	}

	////////////// -potenz (double, int)- //////////////		
	/**
	 * calculates x^n
	 * @param x
	 * @param n
	 * @return x^n as double
	 */
	public static double potenz(double x, int n) 
	{
		double produkt = 1;

		if (n >= 0)
			for (int i = 1; i <= n; i++)
				produkt *= x;
		else
			for (int i = 1; i <= (-1) * n; i++)
				produkt /= x;

		return produkt;
	}

	
	////////////// -potenz (int, int)- //////////////	
	/**
	 * calculates x^n for integer values
	 * @param x
	 * @param n
	 * @return x^n as long
	 */
	public static long potenz(int x, int n) 
	{
		long produkt = 1;

		if (n < 0)
			throw new java.lang.IllegalArgumentException();
		for (int i = 1; i <= n; i++)
			produkt *= x;

		return produkt;
	}

	
	////////////// -ggT- //////////////	
	/**
	 * calculates the greatest common divider
	 * @param n
	 * @param m
	 * @return GGT(n,m)
	 */
	public static int ggT(int n, int m) 
	{
		if (m < 1 || n < 1)
			throw new java.lang.IllegalArgumentException();

		int r;

		if (m < n) 
		{
			r = m;
			m = n;
			n = r;
		}

		do 
		{
			r = m % n;
			m = n;
			n = r;
		} while (r != 0);

		return m;
	}

	
	////////////// -isPrime (int)- //////////////
	/**
	 * test n to be a prime number
	 * @param n
	 * @return true if n is prime, false otherwise
	 */
	public static boolean isPrime(int n) 
	{
		if (n <= 1)
			return false;

		if (n == 2)
			return true;

		// n gerade?
		if (n % 2 == 0)
			return false;

		// existiert ungerader Teiler?
		for (int i = 3; i * i <= n; i += 2)
			if (n % i == 0)
				return false;

		return true;
	}

	
	////////////// -isPrime (BigInteger)- //////////////	
	/**
	 * test n to be a prime number
	 * @param n BigInteger
	 * @return true if n is prime, false otherwise
	 */
	public static boolean isPrime(BigInteger n) 
	{

		//TO BE DONE
		
	}
	
	
	////////////// -binomialCoefficient- //////////////	
	/**
	 * calculates binomial coefficient n over k
	 * @param n
	 * @param k
	 * @return n over k
	 */
	public static long binomialCoefficient(int n, int k) 
	{
		if (n == 0 || k == 0 || n == k)
			return 1;
		else
			return binomialCoefficient(n - 1, k - 1)
				+ binomialCoefficient(n - 1, k);
	}
	

	////////////// -getPascalArray- //////////////	
	/**
	 * generates pascal array of length
	 * @param length
	 * @return the two dimensional array
	 */
	public static long[][] getPascalArray(int length) 
	{
		long[][] array = new long[length][];
		for (int i = 0; i <= length - 1; i++)
			array[i] = new long[i + 1];

		for (int zeile = 1; zeile <= length; zeile++)
			for (int spalte = 1; spalte <= zeile; spalte++)
				array[zeile - 1][spalte - 1] =
					binomialCoefficient(zeile - 1, spalte - 1);

		return array;
	}
}
